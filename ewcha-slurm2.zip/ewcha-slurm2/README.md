## Работа для Devops Upgrade, Комфорт. Поток 8

Install Prometheus + Node_exporter + ELK + Fluent-bit :

- OS - Ubuntu 22.04 ;

- Repo ELK - Sanction - 403;

- Garbage after download or install .

- Open ports UFW

- Deb ELK - too long installation

- Идемпотентность на хорошем уровне

- Это был удивительный (нет) погружение в мир санкций

- Приложения скоро придется в роль класть

- Иногда виснет на Deb Kibana, интеграции не все добила

PLAY RECAP ************************************************************************************************************************************
192.168.92.137             : ok=46   changed=12   unreachable=0    failed=0    skipped=0    rescued=0    ignored=0   

● prometheus.service - Prometheus
     Loaded: loaded (/etc/systemd/system/prometheus.service; enabled; vendor pr>
     Active: active (running) since Tue 2024-10-22 17:30:33 UTC; 11min ago
   Main PID: 7919 (prometheus)
      Tasks: 7 (limit: 4513)
     Memory: 36.2M
        CPU: 1.235s
     CGroup: /system.slice/prometheus.service
             └─7919 /usr/local/bin/prometheus --config.file=/etc/prometheus/pro>

● node_exporter.service - Node Exporter
     Loaded: loaded (/etc/systemd/system/node_exporter.service; enabled; vendor>
     Active: active (running) since Tue 2024-10-22 17:25:17 UTC; 18min ago
   Main PID: 5574 (node_exporter)
      Tasks: 4 (limit: 4513)
     Memory: 13.0M
        CPU: 2.582s
     CGroup: /system.slice/node_exporter.service
             └─5574 /usr/local/bin/node_exporter
● elasticsearch.service - Elasticsearch
     Loaded: loaded (/lib/systemd/system/elasticsearch.service; enabled; vendor>
     Active: active (running) since Tue 2024-10-22 17:33:06 UTC; 12min ago
       Docs: https://www.elastic.co
   Main PID: 8338 (java)
      Tasks: 76 (limit: 4513)
     Memory: 2.3G
        CPU: 1min 20.068s
     CGroup: /system.slice/elasticsearch.service
             ├─8338 /usr/share/elasticsearch/jdk/bin/java -Xms4m -Xmx64m -XX:+U>
             ├─8396 /usr/share/elasticsearch/jdk/bin/java -Des.networkaddress.c>
             └─8416 /usr/share/elasticsearch/modules/x-pack-ml/platform/linux-x>
